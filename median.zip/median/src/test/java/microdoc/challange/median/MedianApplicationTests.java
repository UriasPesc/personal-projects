package microdoc.challange.median;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedianApplicationTests {

	@Test
	void contextLoads() {
	}

}
