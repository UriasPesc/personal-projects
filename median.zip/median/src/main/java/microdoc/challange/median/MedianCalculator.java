package microdoc.challange.median;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class MedianCalculator {


    //Calculates the median of the list of numbers given the KthSmallest element. The algorithm runs in O(n)
    public Double median(List<Double> list){

        double median=0;

        int length = list.size();
        if ((length & 1) == 0) // even
            return (findKthSmallest(list, list.size() / 2) + findKthSmallest(list, list.size() / 2 + 1)) / 2;
        else // odd
            return findKthSmallest(list, list.size() / 2);
    }


    //Hoare's algorithm to find the k-th smallest of element of n items.
    public double findKthSmallest(List<Double> list, int k)
    {
        //If the list contains a small number of elements it sorts it
        if (list.size() < 10)
        {
            Collections.sort(list);
            return list.get(k);
        }

        //Otherwise proceeds without sorting
        int start = 0;
        int end = list.size() - 1;
        double x, temp;
        int i, j;
        while (start < end)
        {
            x = list.get(k);
            i = start;
            j = end;
            do
            {
                while (list.get(i) < x)
                    i++;
                while (x < list.get(j))
                    j--;
                if (i <= j)
                {
                    temp = list.get(i);
                    list.set(i,list.get(j));
                    list.set(j,temp);
                    i++;
                    j--;
                }
            } while (i <= j);
            if (j < k)
                start = i;
            if (k < i)
                end = j;
        }
        return list.get(k);
    }
}
