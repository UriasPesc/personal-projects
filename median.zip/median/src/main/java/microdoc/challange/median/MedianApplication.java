package microdoc.challange.median;


import java.util.Scanner;

public class MedianApplication {

	public static void main(String[] args)
			throws Exception
	{
	    //Reads the file from stdIn
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please indicate the path of the text file");
        String file = scanner.nextLine();
        MedianCalculator mc =  new MedianCalculator();
        ReadFile rf = new ReadFile();

        System.out.println("The median of the list of elements is: "+mc.median(rf.readsFile(file)));


        //Fills a list object with the contents of the file by line Java8
     /*   List<Double> nums = Files.lines(Paths.get(file))
                .map(Double::parseDouble)
                .collect(Collectors.toList());*/

        //When considering splitting the file
        //Split s = new Split(file);
		//s.processAll(5, 1000);

	}

}
