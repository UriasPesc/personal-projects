# GK Software Total Calculator
(***please follow [Stack Edit](https://stackedit.io/app#) to visualize this markdown***)

This file contains information on how to execute the code for the tasks to implement a simple price calculator that calculates prices for receipt positions.
For this the reading and processing of the fields contained in the attached **ItemList.json** file. 

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. 

### Prerequisites
To start is required to have an **IDE** to work on the code and also the **Java SE Runtime Environment**, additionally to proceed with certain configurations that you can see on the following steps.
You will need to install:

```
* Eclipse
* Spring Tool Suite
* Java SE Runtime Environment
* Maven
```

### Installing

You can follow this [link](https://www.eclipse.org/downloads/packages/installer) to see the steps to get your IDE running.
As mentioned, you will require a Java SE Runtime Environment, for this follow the [instructions](https://docs.oracle.com/javase/10/install/installation-jdk-and-jre-microsoft-windows-platforms.htm#JSJIG-GUID-A7E27B90-A28D-4237-9383-A58B416071CA) provided by Oracle.

In case of Spring Tool Suite follow the [link.](https://spring.io/tools3/sts/all)


## Importing the project and libraries

1. On Eclipse or STS, from the main menu bar, select  command link File > Import.... The Import wizard opens.
2. Select General > Existing Project into work space and click Next.
3. Choose either Select root directory or Select archive file and click the associated Browse to locate the directory or file containing the projects.
4. Under Projects select the project or projects which you would like to import.
5. Click Finish to start the import.

## Running and Testing the code

In this section the execution of and reviewing of the testcases can be found.

### src/main/java

This package contains the code for the calculations, under the package gk_software the you can find the main method with the driver code.
```
To simply run the code, go to the **Run** menu on Eclipse or STS and observe the results.
The driver code reads and iterates the list of positions from the **ItemList.json** file.
```

### src/test/java

Under this path you can find the packages for the testing of the calculation module together with parsing and calculation classes.

```
To Execute is required to right click on this class > Run As > JUnit Test

```

## Executable JAR

Here is explained how to create a JAR file from the project and to run it in command line.

### Installing Maven
To generate the JAR file is required to have Maven installed in your system, for this follow this [link.](https://www.mkyong.com/maven/how-to-install-maven-in-windows/)

### Creating the JAR

To build the project execute the following command in your project folder:

```
mvn clean install
```

To package the project inside the JAR, run:
```
mvn clean package
```
The JAR will be generated inside the "target" folder.

On the log you will see the JAR being created as well as the tests, for example:

```
-------------------------------------------------------
 T E S T S
-------------------------------------------------------
Running parser.test.parserTest
Tests run: 3, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.393 sec

Running utilities.test.itemCalculationsTest

Base Price:5.99
Item Description:Truffle Gourmet Pasta
Units:1
Percentage Discount:0.0
Item ID:40133
TOTAL: 5.99
=================================

Base Price:0.28
Item Description:Roll
Units:4
Percentage Discount:35.0
Item ID:300198
TOTAL: 0.73
=================================

Base Price:2.89
Item Description:Chocolate
Units:3
Percentage Discount:0.0
Item ID:300858
TOTAL: 8.67
=================================

Base Price:0.99
Item Description:Soft Drink
Units:0
Percentage Discount:10.0
Item ID:300158
TOTAL: 0.0
=================================

Base Price:0.3
Item Description:Yogurt
Units:6
Percentage Discount:0.0
Item ID:300181
TOTAL: 1.8
=================================

TOTAL: 0.73
Tests run: 2, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.027 sec

Results :

Tests run: 5, Failures: 0, Errors: 0, Skipped: 0
```

### Executing the App

To execute the app, open the cmd inside the target folder or move the JAR file to a different folder.
then execute:
```
java -jar [JAR_FILE_NAME].jar 
```


## Built With

* [Eclipse](https://www.eclipse.org/downloads/packages/installer) - Original code
* [Spring Tool Suite](https://spring.io/tools3/sts/all) -  Modification of the original Eclipse project
* [Maven](https://maven.apache.org/) - Dependency Management
* [Jackson](https://www.mkyong.com/java/how-to-convert-java-object-to-from-json-jackson/)  - JSON Parsing


## Authors

* **Jorge Urías Peña Escajeda** - *Initial work* - [GK Software](https://www.gk-software.com/en/)

See also the list of [contributors](https://www.gk-software.com/en/) who participated in this project.

## License

This project is licensed under the GK Software License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

* [How to do in Java](https://howtodoinjava.com/json/json-simple-read-write-json-examples/)
* Martin Schuberts : MSchuberts@gk-software.com
* [README template](https://gist.github.com/PurpleBooth/109311bb0361f32d87a2)
* [A simple Unit test](http://tutorials.jenkov.com/java-unit-testing/simple-test.html)
* [MKyong](https://www.mkyong.com/java/how-to-convert-java-object-to-from-json-jackson/)
* https://code.tutsplus.com/tutorials/top-15-best-practices-for-writing-super-readable-code--net-8118



