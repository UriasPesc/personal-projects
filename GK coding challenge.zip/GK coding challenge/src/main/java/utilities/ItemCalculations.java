package utilities;

import java.math.BigDecimal;
import java.math.RoundingMode;

import model.ItemList;

public class ItemCalculations {

	public double calculateItem(ItemList[] item)
	{		
		double totalList=0;

		for(int i=0;i<item.length;i++){

			//Get Item base price
			System.out.println("Base Price:"+item[i].getBasePrice());

			//Get Item description
			System.out.println("Item Description:"+item[i].getItemDescription()); 

			//Get Item units

			System.out.println("Units:"+item[i].getUnits());
			//Get Item percentageDiscount

			System.out.println("Percentage Discount:"+item[i].getPercentageDiscount());

			//Get Item itemId
			System.out.println("Item ID:"+item[i].getItemId());

			totalList+=calculateTotalPerItem(item[i]).doubleValue();

			System.out.println("=================================\n");
		}
		return totalList;
	}

	//Calculate price after discount
	public BigDecimal calculateTotalPerItem(ItemList item) {
		double currentPrice=0;

		currentPrice = item.getBasePrice()-(item.getBasePrice()*item.getPercentageDiscount()/100);

		//Total per Item Rouding two decimals
		BigDecimal bd = new BigDecimal(Double.toString(currentPrice*item.getUnits()));
		bd = bd.setScale(2, RoundingMode.HALF_UP);
		System.out.println("TOTAL: "+bd.doubleValue());
		return bd;
	}

}
