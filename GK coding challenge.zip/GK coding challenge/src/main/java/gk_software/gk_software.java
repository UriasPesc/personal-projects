package gk_software;

import model.ItemList;
import parser.ItemJsonParser;
import utilities.ItemCalculations;
public class gk_software {

	public static void main(String[] args) {
		double totalList=0;
		String fileName="ItemList.json";
		ItemJsonParser jp = new ItemJsonParser();
		ItemCalculations ic = new ItemCalculations();
		ItemList[] items=jp.parseJSON(fileName);
		totalList=ic.calculateItem(items);				
		System.out.println("TOTAL LIST: "+totalList);

	}
}
//import org.json.simple.JSONObject;

//import com.fasterxml.jackson.databind.ObjectMapper;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;
//TODO Auto-generated method stub


//@SuppressWarnings("unchecked")

/*	JSONParser jsonParser = new JSONParser();

		//Reading JSON file from workspace
		try (FileReader reader = new FileReader("ItemList.json"))
		{
			//Read JSON file
			Object obj = jsonParser.parse(reader);

			JSONArray itemList = (JSONArray) obj;
			System.out.println(itemList);
			System.out.println("=================================\n");

			//Create ItemCalculations object
			ItemList ci = new ItemList();

			//Iterate over Item array
			itemList.forEach( item -> ci.calculateItem((JSONObject) item));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}*/


