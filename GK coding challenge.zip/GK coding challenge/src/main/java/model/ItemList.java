package model;

public class ItemList
{
	double basePrice;
	String itemDescription;
	long units;
	double percentageDiscount;
	String itemId;				

	/*	public ItemList(double basePrice, String itemDescription, long units, double percentageDiscount, String itemId)
	{
		this.basePrice=basePrice;
		this.itemDescription=itemDescription;
		this.units=units;
		this.percentageDiscount=percentageDiscount;
		this.itemId=itemId;
	}*/

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public long getUnits() {
		return units;
	}

	public void setUnits(long units) {
		this.units = units;
	}

	public double getPercentageDiscount() {
		return percentageDiscount;
	}

	public void setPercentageDiscount(double percentageDiscount) {
		this.percentageDiscount = percentageDiscount;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}


	@Override
	public String toString()
	{
		return "ItemList [basePrice=" + basePrice + ", itemDescription=" + itemDescription + ", " +
				"units=" + units +", "+ "percentageDiscount=" + percentageDiscount+", "+ "itemId=" + itemId + "]";
	}

	/*import org.json.simple.JSONObject;
	import org.json.simple.JSONArray;
	import org.json.simple.parser.JSONParser;
	import org.json.simple.parser.ParseException;*/

	/*public void calculateItem(JSONObject Item)
	{		
		JSONObject itemObject = (JSONObject) Item;//.get("ItemList");

		//Get Item basePrice
		basePrice = (double) itemObject.get("basePrice");  
		System.out.println("Base Price:"+basePrice);

		//Get Item description
		itemDescription = (String) itemObject.get("itemDescription"); 
		System.out.println("Item Description:"+itemDescription); 

		//Get Item units
		if(itemObject.containsKey("units"))
		{
			units = (long) itemObject.get("units");   
			System.out.println("Units:"+units);
		}

		//Get Item percentageDiscount
		if(itemObject.containsKey("percentageDiscount"))
		{
			percentageDiscount = (double) itemObject.get("percentageDiscount");
			System.out.println("Percentage Discount:"+percentageDiscount);

		}
		//Get Item itemId
		itemId = (String) itemObject.get("itemId");   
		System.out.println("Item ID:"+itemId);

		//Calculate price after discount if applies
		currentPrice = basePrice-(basePrice*percentageDiscount/100);

		//Total per Item Rouding two decimals
		total = currentPrice*units;
		BigDecimal bd = new BigDecimal(Double.toString(total));
		bd = bd.setScale(2, RoundingMode.HALF_UP);
		System.out.println("TOTAL: "+bd.doubleValue());



		System.out.println("=================================\n");
	}*/

}
