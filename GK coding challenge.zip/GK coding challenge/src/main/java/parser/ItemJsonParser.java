package parser;

import java.io.File;
import java.io.IOException;

import org.codehaus.jackson.map.ObjectMapper;

import model.ItemList;

public class ItemJsonParser {

	public ItemList[] parseJSON(String fileName)
	{
		ItemList[] items=null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			// Convert JSON string from file to Object
			items = mapper.readValue(new File(fileName), ItemList[].class);
		}catch (IOException e) {
			throw new RuntimeException("Could not parse JSON");
		}

		return items;
	}
}
