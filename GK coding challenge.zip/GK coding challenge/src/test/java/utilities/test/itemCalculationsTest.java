package utilities.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.junit.Before;
import org.junit.Test;

import model.ItemList;
import parser.ItemJsonParser;
import utilities.ItemCalculations;

public class itemCalculationsTest {

	ItemCalculations ic = new ItemCalculations();
	ItemJsonParser ijp = new ItemJsonParser();
	ItemList[] items=null;
	
	@Before
	public void setUp() {
		this.items=ijp.parseJSON("ItemList.json");
	}
	
	//Expected result test on the total of the list
	@Test
	public void calculateItemTest() {
		double result=ic.calculateItem(items);
		assertEquals(17.19d, result,0.01);
	}
	
	//Expected test on a single position of the list
	@Test
	public void calculateTotalPerItemTest() {
		ItemList item= new ItemList();
		item.setBasePrice(0.28);
		item.setItemDescription("Roll");
		item.setUnits(4);
		item.setPercentageDiscount(35.0);
		item.setItemId("300198");
		
		BigDecimal expected = new BigDecimal(0.73).setScale(2,RoundingMode.HALF_UP);
		assertEquals(expected, ic.calculateTotalPerItem(item));		
		
		
	}

}
