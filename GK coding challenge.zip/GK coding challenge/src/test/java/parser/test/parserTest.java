package parser.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import model.ItemList;
import parser.ItemJsonParser;

public class parserTest {

	ItemJsonParser ijp = new ItemJsonParser();
	ItemList[] items=null;

	@Before
	public void setUp() {
		this.items=ijp.parseJSON("ItemList.json");
	}

	//Positive test checking the parsing for one element on the list
	@Test
	public void parseJSONTest(){

		ItemList[] result= ijp.parseJSON("ItemList.json");
		assertEquals("40133",result[0].getItemId());
		assertEquals(5,result.length);
	}

	//Negative test on an intentional missformated json file
	@Test(expected=RuntimeException.class)
	public void parseJSONFailureTest(){

		ItemList[] result= ijp.parseJSON("ItemListFail.json");
	}

	//Negative test expecting an exception on parsing
	@Test
	public void parseJSONFailureTest2(){

		try {
			ItemList[] result= ijp.parseJSON("ItemListFail.json");
		}catch(RuntimeException e){

			assertThat("Could not parse JSON", is(e.getMessage()));
		}
	}

}
