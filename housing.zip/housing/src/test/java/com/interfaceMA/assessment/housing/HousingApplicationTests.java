package com.interfaceMA.assessment.housing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HousingApplicationTests {

	@Test
	void contextLoads() {
	}

}
