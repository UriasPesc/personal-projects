package com.interfaceMA.assessment.housing.service;

import com.interfaceMA.assessment.housing.model.House;

import java.util.ArrayList;
import java.util.List;

public interface HouseService {

    public List<House> getHousesByParam(String sortBy);
    public ArrayList<List<House>> getHousesFiltered();

}
