package com.interfaceMA.assessment.housing.util;

import com.interfaceMA.assessment.housing.model.Coordinates;

public class CoordinatesUtil {

    //Calculates the distance given the coorditates of two objects using latitude and longitude, returns the value in Kilometers
    public static Double calculateDistance(Coordinates coorA, Coordinates coorB){

        if ((coorA.getLat() == coorB.getLat()) && (coorA.getLon() == coorB.getLon())) {
            return 0.0;
        }
        else {
            double theta = coorA.getLon() - coorB.getLon();
            double dist = Math.sin(Math.toRadians(coorA.getLat())) * Math.sin(Math.toRadians(coorB.getLat())) +
                    Math.cos(Math.toRadians(coorA.getLat())) * Math.cos(Math.toRadians(coorB.getLat())) * Math.cos(Math.toRadians(theta));
            dist = Math.acos(dist);
            dist = Math.toDegrees(dist);
            dist = dist * 60 * 1.1515;

                dist = dist * 1.609344;
            return (dist);
        }

    }
}
