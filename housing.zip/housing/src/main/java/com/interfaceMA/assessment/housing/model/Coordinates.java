package com.interfaceMA.assessment.housing.model;

public class Coordinates {

    //Initialized in zero by default to avoid issues with possible null mappings
    private Double lat =0.0;
    private Double lon = 0.0;

    public Coordinates() {
    }

    public Coordinates(Double lat, Double lon) {
        this.lat = lat;
        this.lon = lon;
    }


    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        //Checks if the property is mapped with a valid value
        if(lat!=null) this.lat = lat;;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        //Checks if the property is mapped with a valid value
        if(lon!=null) this.lon = lon;;
    }
}
