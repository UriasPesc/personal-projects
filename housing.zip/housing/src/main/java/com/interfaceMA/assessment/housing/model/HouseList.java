package com.interfaceMA.assessment.housing.model;

import java.util.List;

public class HouseList {

    private List<House> houses;

    public List<House> getHouses() {
        return houses;
    }

    public void setHouses(List<House> houses) {
        this.houses = houses;
    }
}
