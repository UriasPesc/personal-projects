package com.interfaceMA.assessment.housing.repository;

import com.interfaceMA.assessment.housing.model.Coordinates;
import com.interfaceMA.assessment.housing.model.House;
import com.interfaceMA.assessment.housing.model.HouseList;
import com.interfaceMA.assessment.housing.util.CoordinatesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class HouseRepositoryImpl implements HouseRepository {

    //Retrieves the list from the given source
    private static String URL  ="https://demo.interfacema.de/programming-assessment-1.0/buildings";

    @Autowired
    RestTemplate restTemplate;

    //Implementation of the method findAll() to retrieve the complete list from the source
    @Override
    public List<House> findAll() {
        HouseList response = restTemplate.getForObject(URL, HouseList.class);
        List<House> result=response.getHouses();
        return result;

    }

    //Implementation of findByDistance() comparing each house with the information given of a specific point, in this case the sister's house
    @Override
    public List<House> findByDistance(List<House> houses, Double lan, Double lon) {

        //Compares and sorts by ascendant order the distance between each house and the given point.
        Coordinates coorComp = new Coordinates(lan,lon);
        return houses.stream().sorted(Comparator.comparing(a-> CoordinatesUtil.calculateDistance(coorComp, a.getCoords()))).
                collect(Collectors.toList());
    }

    //Implementation of findByRooms() comparing elements in the list of objects with 5 or more rooms and sorts in ascendant order
    @Override
    public List<House> findByRooms(List<House> houses) {
        //Checks if the property params is not null and proceeds to check number of rooms and sorts
        return houses.stream().filter(a->a.getParams()!=null).filter(a->a.getParams().
                getRooms()>=5).sorted(Comparator.comparing(a->a.getParams().getRooms())).
                collect(Collectors.toList());

    }

    //Implementation of findIncomplete()
    @Override
    public List<House> findIncomplete(List<House> houses) {
        //Checks if any of the properties are null or got mapped by default to review incomplete information
        //returns a list in ascendant order by street name
        return houses.stream().filter(a->a.getParams()==null || a.getCoords()==null
                        || a.getCoords().getLat()==0.0 || a.getCoords().getLon()==0.0
                        || a.getParams().getValue()==0 || a.getParams().getRooms()==0).
                sorted(Comparator.comparing(a->a.getStreet())).collect(Collectors.toList());

    }


}
