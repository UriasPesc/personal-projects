package com.interfaceMA.assessment.housing.controller;

import com.interfaceMA.assessment.housing.model.House;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.interfaceMA.assessment.housing.service.HouseService;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("housing")
public class HouseController {

    //Autowired object of the service
    @Autowired
    HouseService houseService;

    //In case the lists want to be retrieve individually given a parameter "distance", "rooms", or default (incomplete info)
    @GetMapping("/param")
    public List<House> getAllHouse(@RequestParam(required = false) String sortBy) {

        return houseService.getHousesByParam(sortBy);

    }

    //Service that retrieves a list of sub-lists with all the filtering criteria (number of rooms, distance, incomplete info)
    @GetMapping("/filtered")
    public ArrayList<List<House>> getAllHouseFiltered(@RequestParam(required = false) String sortBy) {

        return houseService.getHousesFiltered();

    }
}
