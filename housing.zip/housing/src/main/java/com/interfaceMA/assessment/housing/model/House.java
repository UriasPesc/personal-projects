package com.interfaceMA.assessment.housing.model;


public class House {

    Coordinates coords;
    Params params;
    String street;


    public House(){

    }

    public House(Coordinates coords, Params params, String street) {
        this.coords = coords;
        this.params = params;
        this.street = street;
    }


    public Coordinates getCoords() {
        return coords;
    }

    public void setCoords(Coordinates coords) {
        this.coords = coords;
    }

    public Params getParams() {
        return params;
    }

    public void setParams(Params params) {
        this.params = params;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }
}
