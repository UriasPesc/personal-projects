package com.interfaceMA.assessment.housing.service;

import com.interfaceMA.assessment.housing.model.House;
import org.springframework.beans.factory.annotation.Autowired;
import com.interfaceMA.assessment.housing.repository.HouseRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class HouseServiceImpl implements HouseService {

    @Autowired
    HouseRepository houseRepository;

    //In case the lists want to be retrieve individually given a parameter "distance", "rooms", or default (incomplete info)
    @Override
    public List<House> getHousesByParam(String sortBy) {

        List<House> houses = houseRepository.findAll();
        List<House> finalResult = null;

        switch (sortBy){

            case "distance":
                //Comparing to the Sister's coordinates
                finalResult = houseRepository.findByDistance(houses, 52.5418739, 13.4057378 );
                break;
            case "rooms":
                finalResult = houseRepository.findByRooms(houses);
                break;
            default:
                finalResult = houseRepository.findIncomplete(houses);
                break;
        }
            return finalResult;

    }

    //Retrieves a list of sub-lists with all the filtering criteria (number of rooms, distance, incomplete info)
    @Override
    public ArrayList<List<House>> getHousesFiltered() {
        List<House> houses = houseRepository.findAll();
        ArrayList<List<House>> allHouses = new ArrayList<List<House>>();

        allHouses.add(houseRepository.findByDistance(houses, 52.5418739, 13.4057378 ));
        allHouses.add(houseRepository.findByRooms(houses));
        allHouses.add(houseRepository.findIncomplete(houses));

        return allHouses;
    }
}
