package com.interfaceMA.assessment.housing.model;

public class Params {

    //Initialized in zero by default to avoid issues with possible null mappings
    private Integer rooms=0;
    private Integer value=0;

    public Params(){

    }

    public Params(Integer rooms, Integer value) {
        this.rooms = rooms;
        this.value = value;
    }

    public Integer getRooms() {
        return rooms;
    }

    public void setRooms(Integer rooms) {
        //Checks if the property is mapped with a valid value
        if(rooms!=null) this.rooms = rooms;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        //Checks if the property is mapped with a valid value
        if(value!=null) this.value = value;
    }
}
