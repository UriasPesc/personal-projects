package com.interfaceMA.assessment.housing.repository;

import com.interfaceMA.assessment.housing.model.House;

import java.util.List;

public interface HouseRepository {

    public List<House> findAll();
    public List<House> findByDistance(List<House> houses, Double lat, Double lon);
    public List<House> findByRooms(List<House> houses);
    public List<House> findIncomplete(List<House> houses);
}
